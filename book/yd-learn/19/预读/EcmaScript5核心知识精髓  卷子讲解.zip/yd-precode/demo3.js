this.a = 20;
//constructorable
function go() {
  //this = Object.create(go.prototype)
  //this.__proto__ = go.prototype 
  console.log(this.a);
  this.a = 30;
  // return this
}
go.prototype.a = 40;
var test = {
  a: 50,
  init: function (fn) {
    fn();
    console.log(this.a);
    return fn;
  }
};
console.log(((new go).a))
test.init(go);
var p = test.init(go);
p();

//40  30 
//20  50
//30  50
//30