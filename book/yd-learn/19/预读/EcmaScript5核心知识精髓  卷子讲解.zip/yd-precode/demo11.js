var regex = /yideng/g;
console.log(regex.test('yideng'));
console.log(regex.lastIndex)
console.log(regex.test('yideng'));
console.log(regex.lastIndex)
console.log(regex.test('yideng'));
console.log(regex.lastIndex)
console.log(regex.test('yideng'))
console.log(regex.lastIndex)