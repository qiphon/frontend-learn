alert(a)
a();
var a = 3;

function a() {
  alert(10)
}
alert(a)
a = 6;
a()

// //编译
// var a

// function a() {
//   alert(10)
// }

// //执行
// alert(a)
// a();
// a = 3;
// alert(a)
// a = 6;
// a() //callable