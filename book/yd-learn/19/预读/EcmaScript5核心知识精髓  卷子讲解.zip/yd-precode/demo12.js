var yideng = function yideng() {
  yideng = 1;
  //debugger
  console.log(typeof yideng);
}
yideng();
yideng = 1;
console.log(typeof yideng);