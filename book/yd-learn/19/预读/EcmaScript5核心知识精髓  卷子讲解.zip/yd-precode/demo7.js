function yideng() {
  console.log(1);
}
(function () {
  console.log(yideng)
  if (false) {
    function yideng() {
      console.log(2);
    }
  }
  //console.log(yideng)
  yideng();
})();

//es6 块级作用域函数