//转数组
var str = 'a🍎c'
// var arr = str.split('')
// console.log(arr)
// var arr = Array.from(str)
// for (let item of str) {
//   console.log(item)
// }
console.log([...str])