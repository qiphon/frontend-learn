var length = 10;

function fn() {
  console.log(this.length);
}
var yideng = {
  length: 5,
  method: function (fn) {
    console.log(this.length)
    fn();
    arguments[0]();
  }
};
yideng.method(fn, 1, 3, 5);