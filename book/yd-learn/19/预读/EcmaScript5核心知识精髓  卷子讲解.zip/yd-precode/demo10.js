// class Car {
//   constructor(color, price) {
//     this.color = color
//     this.price = price
//   }
//   static age = 10
//   say() {
//     console.log(`${this.color}and${this.price}`)
//   }
// }

// class Cruze extends Car {
//   constructor(color, price) {
//     super(color, price)
//   }
// }

// let cruze = new Cruze('红色', 140000)
// console.log(Cruze.age)
// cruze.say()

// function Car(color, price) {
//   this.color = color
//   this.price = price
// }
// Car.prototype.say = function () {
//   console.log(`${this.color}and${this.price}`)
// }

// function Cruze(color, price) {
//   Car.call(this, color, price)
// }

// Cruze.prototype = Object.create(Car.prototype, {
//   constructor: {
//     value: Cruze
//   }
// })
// Car.age = 10
// for (let [key, value] of Object.entries(Car)) {
//   Cruze[key] = value
// }
// let cruze = new Cruze('红色', 140000)
// console.log(Cruze.age)
// cruze.say()