function test(m) {

  m = {
    v: 5
  }
}
var m = {
  k: 30
};
test(m);
alert(m.v);