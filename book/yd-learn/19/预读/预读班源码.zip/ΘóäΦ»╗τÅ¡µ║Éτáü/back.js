// var regex = /foo/g;

// regex.test('foo'); // true
// regex.test('foo'); // false
// const allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;
// function cloneBuffer(buffer, isDeep) {
//     if (isDeep) {
//         return buffer.slice();
//     }
//     const length = buffer.length;
//     const result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
//     buffer.copy(result);
//     return result;
// }
// const buf = Buffer.from("laoyuan");
// // const buf2 = buf;
// const buf2 = cloneBuffer(buf, false);
// buf2.write("nodejs");
// buf2.write("22");
// console.log("buf", buf.toString("utf-8"));
// console.log("buf2", buf2.toString("utf-8"));

//面向对象 constructor + 5分 静态属性
// Car.prototype.constructor = Car;
// Object.create({
//     value: Car,
//     writeable: false
// })
// const s = "京程一灯"; // allocUnsafe

//正则
const flags = /\w*$/;
function cloneRegExp(regexp){
    // /^67/ . constructor = RegExp;
    let result = new regexp.constructor(regexp.source,/\w*$/.exec(regexp));
    result.lastIndex = regexp.lastIndex;
    // result.lastIndex = 0;
    return result;
}
const regex1 = /foo/g;
let regex2 = cloneRegExp(regex1);
regex2 = /yideng/g;
console.log("regex",regex1);
console.log("regex2",regex2);
// regex.test('foo'); 
// regex2.test('foo'); // false