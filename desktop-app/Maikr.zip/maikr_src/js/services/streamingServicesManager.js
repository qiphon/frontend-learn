(function() {
	var streamingServicesManager;
	streamingServicesManager = function($rootScope, $log, $translate) {

		this.services = {

        	"hulu":{
        		"name": "Hulu",
        		"logo": "hulu.png",
        		"url" : "https://www.hulu.com"
        	},
        	"happyon":{
        		"name": "Happyon(hulu.jp)",
        		"logo": "happyon.png",
        		"url" : "https://www.hulu.jp"
        	},
        	"hbo":{
        		"name": "HBO",
        		"logo": "hbo.png",
        		"url" : "https://www.hbo.com"
        	},
        	"hbogo":{
        		"name": "HBO Go",
        		"logo": "hbogo.png",
        		"url" : "https://www.hbogo.com"
        	},
        	"hbonow":{
        		"name": "HBO Now",
        		"logo": "hbonow.png",
        		"url" : "https://www.hbonow.com"
        	},
        	"bbc":{
        		"name": "BBC iPlayer",
        		"logo": "bbc.png",
        		"url" : "https://www.bbc.co.uk/iplayer"
        	},
        	"tvb":{
        		"name": "TVB",
        		"logo": "tvb.png",
        		"url" : "https://www.tvb.com"
        	},
        	"sling":{
        		"name": "Sling",
        		"logo": "sling.png",
        		"url" : "https://www.sling.com"
        	},
        	"disney+":{
        		"name": "Disney+",
        		"logo": "disney_plus.png",
        		"url" : "https://www.disneyplus.com"
        	},
        	"fox+":{
        		"name": "Fox+",
        		"logo": "fox_plus.png",
        		"url" : "https://www.foxplus.com"
        	},
            "foxnews":{
                "name": "FoxNews",
                "logo": "foxnews.png",
                "url" : "https://www.foxnews.com/"
            },
        	"niconico":{
        		"name": "Niconico",
        		"logo": "niconico.png",
        		"url" : "https://www.nicovideo.jp/"
        	},
        	"dmm":{
        		"name": "DMM",
        		"logo": "dmm.png",
        		"url" : "https://www.dmm.co.jp"
        	},
        	"tver":{
        		"name": "TVer",
        		"logo": "tver.png",
        		"url" : "https://tver.jp"
        	},
        	"tw_gamer":{
        		"name": "動畫瘋",
        		"logo": "tw_gamer.png",
        		"url" : "https://ani.gamer.com.tw/"
        	},
        	"vrv":{
        		"name": "VRV",
        		"logo": "vrv.png",
        		"url" : "https://vrv.co/"
        	},
        	"viu":{
        		"name": "Viu",
        		"logo": "viu.png",
        		"url" : "https://www.viu.com/"
        	},
        	"4gtv":{
        		"name": "四季線上影視",
        		"logo": "4gtv.png",
        		"url" : "https://www.4gtv.tv"
        	}
        };


            this.getSpecials = function(server) {
                if(server.specials && server.specials !== ''){
                    return server.specials.split(",");
                }
            };
        this.isNetflix = function(special) {
            if(special){
                return special.contains('netflix');
            }
            return false;
        };


        this.isNetflix = function(special) {
            if(special){
                return special.contains('netflix');
            }
            return false;
        };

        this.netflixWithArea = function(special) {
                    if(special.startsWith('netflix')){
                        if(special.contains("-")){
                            var area = special.substring(special.indexOf('-') + 1).toUpperCase();
                         
                            if(currentLocale === 'zh_CN'){
                                return $translate.instant("country." + area) + $translate.instant("common.area") + "Netflix";
                            }else{
                                return "Netflix" + $translate.instant("common.area") + area;
                            }
                        }
                    }
            return 'Netflix';

        };
        this.isHulu = function(special) {
            if(special){
                return special.contains('hulu');
            }
            return false;
        };
        this.hulu = function(special) {
            if(this.isHulu(special)){
                return 'Hulu';
            }
            return '';
        };
        this.isHappyon = function(special) {
            if(special){
                return special.contains('happyon');
            }
            return false;
        };
        this.happyon = function(special) {
            if(this.isHappyon(special)){
                return 'Happyon(hulu.jp)';
            }
            return '';
        };
        this.isHbo = function(special) {
            if(special){
                return special.contains('hbo');
            }
            return false;
        };
        this.hbo = function(special) {
            if(this.isHbo(special)){
                return 'HBO';
            }
            return '';
        };
        this.isHbogo = function(special) {
            if(special){
                return special.contains('hbogo');
            }
            return false;
        };
        this.hbogo = function(special) {
            if(this.isHbogo(special)){
                return 'HBO Go';
            }
            return '';
        };
        this.isHbonow = function(special) {
            if(special){
                return special.contains('hbonow');
            }
            return false;
        };
        this.hbonow = function(special) {
            if(this.isHbonow(special)){
                return 'HBO Now';
            }
            return '';
        };
        this.isBbc = function(special) {
            if(special){
                return special.contains('bbc');
            }
            return false;
        };
        this.bbc = function(special) {
            if(this.isBbc(special)){
                return 'BBC';
            }
            return '';
        };
        this.isTvb = function(special) {
            if(special){
                return special.contains('tvb');
            }
            return false;
        };
        this.tvb = function(special) {
            if(this.isTvb(special)){
                return 'TVB';
            }
            return '';
        };
        this.isSling = function(special) {
            if(special){
                return special.contains('sling');
            }
            return false;
        };
        this.sling = function(special) {
            if(this.isSling(special)){
                return 'Sling';
            }
            return '';
        };
        this.isDisneyPlus = function(special) {
            if(special){
                return special.contains('disney+');
            }
            return false;
        };
        this.disneyPlus = function(special) {
            if(this.isDisneyPlus(special)){
                return 'Disney+';
            }
            return '';
        };
        this.isFoxPlus = function(special) {
            if(special){
                return special.contains('fox+');
            }
            return false;
        };
        this.foxPlus = function(special) {
            if(this.isFoxPlus(special)){
                return 'Fox+';
            }
            return '';
        };
        this.isFoxNews = function(special) {
            if(special){
                return special.contains('foxnews');
            }
            return false;
        };
        this.foxNews = function(special) {
            if(this.isFoxNews(special)){
                return 'FoxNews';
            }
            return '';
        };
        this.isNico = function(special) {
            if(special){
                return special.contains('niconico');
            }
            return false;
        };
        this.nico = function(special) {
            if(this.isNico(special)){
                return 'Niconico';
            }
            return '';
        };
        this.isDmm = function(special) {
            if(special){
                return special.contains('dmm');
            }
            return false;
        };
        this.dmm = function(special) {
            if(this.isDmm(special)){
                return 'DMM';
            }
            return '';
        };
        this.isTver = function(special) {
            if(special){
                return special.contains('tver');
            }
            return false;
        };
        this.tver = function(special) {
            if(this.isTver(special)){
                return 'TVer';
            }
            return '';
        };
        this.isTWGamer = function(special) {
            if(special){
                return special.contains('tw_gamer');
            }
            return false;
        };
        this.twGamer = function(special) {
            if(this.isDmm(special)){
                return '動畫瘋';
            }
            return '';
        };
        this.isVrv = function(special) {
            if(special){
                return special.contains('vrv');
            }
            return false;
        };
        this.vrv = function(special) {
            if(this.isVrv(special)){
                return 'VRV';
            }
            return '';
        };
        this.isViu = function(special) {
            if(special){
                return special.contains('viu');
            }
            return false;
        };
        this.viu = function(special) {
            if(this.isViu(special)){
                return 'Viu';
            }
            return '';
        };
        this.is4gtv = function(special) {
            if(special){
                return special.contains('4gtv');
            }
            return false;
        };
        this.fourgtv = function(special) {
            if(this.is4gtv(special)){
                return '四季線上影視';
            }
            return '';
        };


		return this
	};
	define(['../app'], function(app) {
		return app.service('streamingServicesManager', ['$rootScope', '$log', '$translate', streamingServicesManager])
	})
}).call(this);